"""Generate a direct-open HTML using the same source, D3 and real CSV. Python stdlib only."""
from pathlib import Path
import re, json, base64

project=Path(__file__).resolve().parents[1]
root=project/'dist' if (project/'dist').is_dir() else project
files={}
for pattern in ['app/*.js','learn/*.js','learn/*.html','steps/*.html','data/*.csv','data/*.json','vendor/*.js','*.md']:
    for path in root.glob(pattern):
        if path.name in ['answers.js','REPRODUCE_ZH.md','VALIDATION.md','README.md']:continue
        files[str(path.relative_to(root))]=path.read_text()
font=base64.b64encode((root/'fonts/Nunito-Variable.ttf').read_bytes()).decode()
files['app.css']=(root/'app.css').read_text().replace("url('fonts/Nunito-Variable.ttf')", "url('data:font/ttf;base64,"+font+"')")
files['fonts/OFL-Nunito.txt']=(root/'fonts/OFL-Nunito.txt').read_text()
files['learn/index.html']=re.sub(r'<a\b[^>]*href="\.\./index.html#practice"[^>]*>.*?</a>','<p class="small muted">返回课程页面，请切回原来的标签页。 / Return to the original tab for the teaching page.</p>',files['learn/index.html'])
html=(root/'index.html').read_text()
# The direct-open file has no dependency on hosting, login, server or local siblings.
html=re.sub(r'<a\b[^>]*href="original/index.html"[^>]*>.*?</a>','',html)
html=re.sub(r'<a\b[^>]*href="downloads/[^\"]+"[^>]*>.*?</a>','',html)
html=re.sub(r'<p class="offline-copy[^\"]*">.*?</p>','<p class="small muted"><span class="copy-zh">此文件已包含数据、D3 和字体。需要修改工程时，请下载完整 ZIP。</span><span class="copy-en" lang="en">Data, D3 and fonts are embedded. Download the complete ZIP to edit the project.</span></p>',html)
scripts=[]
html=re.sub(r'<link\b[^>]*href="app.css"[^>]*>','<style>'+files['app.css']+'</style>',html)
def collect(match):
    scripts.append(files[match.group(1)])
    return ''
html=re.sub(r'<script\b[^>]*src="([^"]+)"[^>]*></script>',collect,html)
def script(text):return '<script>'+re.sub(r'</(script|body|head|html)',r'<\\/\1',text,flags=re.I)+'</script>'
payload=script('window.LAX_BUNDLE='+json.dumps(files,ensure_ascii=False).replace('<','\\u003c')+';')
html=html.replace('</body>',payload+''.join(map(script,scripts))+'</body>')
output=root/'downloads/lax-direct-open.html'
output.parent.mkdir(exist_ok=True)
output.write_text(html)
print(f'Direct-open edition: {output.stat().st_size:,} bytes; {len(files)} bundled text assets + font.')

# Keep previous direct-open links current, without a visible version label.
for name in ['lax-course-v7.html','lax-workspace.html']:
    (root/'downloads'/name).write_text(html)
print('Workspace edition: lax-workspace.html')

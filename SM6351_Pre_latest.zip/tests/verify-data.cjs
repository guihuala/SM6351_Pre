/* Run from the project folder: node tests/verify-data.cjs. No npm packages. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const context = vm.createContext({window:{}, console});
const read = file => fs.readFileSync(path.join(root,file),'utf8');
for (const file of ['vendor/d3.v7.min.js','app/data.js','app/chart.js']) vm.runInContext(read(file),context,{filename:file});
const {d3,window:{LAX:app}} = context;
const source = d3.csvParse(read('data/lax-passengers.csv'));
const data = app.parseRows(source);
let checks = 0;
function eq(actual, expected, label) {
  assert.equal(actual,expected,label); checks++;
}
const state = (year,traffic='Both',direction='All') => ({start:year,end:year,traffic,direction,sort:'terminal',scale:'shared'});
const total = view => view.panels.reduce((sum,panel)=>sum+panel.reported,0);
eq(data.sourceCount,7883,'snapshot row count');
eq(data.months.length,214,'continuous reporting months');
eq(data.terminals.length,12,'reporting categories');
eq(data.invalid,0,'invalid input rows');
eq(data.duplicates,0,'duplicate reporting cells');
eq(data.months[0].toISOString().slice(0,7),'2006-01','first month');
eq(data.months.at(-1).toISOString().slice(0,7),'2023-10','last month');
eq(data.completeYears.at(-1),2022,'latest year with twelve observed months');
eq(data.rows.filter(row=>row.value===0).length,11,'real zero observations retained');
for (const year of data.years) {
  for (const direction of ['All','Arrival','Departure']) {
    for (const traffic of ['Both','Domestic','International','Total']) {
      // Independent check directly against source strings, not grouped output.
      const expected = source.filter(row => +row.reportperiod.slice(0,4)===year &&
        (direction==='All'||row.arrival_departure===direction) &&
        (['Both','Total'].includes(traffic)||row.domestic_international===traffic))
        .reduce((sum,row)=>sum+Number(row.passenger_count),0);
      eq(total(app.aggregate(data,state(year,traffic,direction))),expected,`${year}/${direction}/${traffic}`);
    }
  }
}
eq(total(app.aggregate(data,state(2019))),88068013,'2019 annual reported total');
eq(total(app.aggregate(data,state(2020))),28779527,'2020 annual reported total');
eq(total(app.aggregate(data,state(2022))),66005087,'2022 annual reported total');
eq(total(app.aggregate(data,state(2022,'Domestic'))),49404242,'2022 domestic total');
eq(total(app.aggregate(data,state(2022,'International'))),16600845,'2022 international total');
const view = app.aggregate(data,state(2022));
const t1 = view.panels.find(panel=>panel.terminal==='T1').values[11];
const tbit = view.panels.find(panel=>panel.terminal==='TBIT').values[11];
eq(t1.Domestic.value,486638,'T1 December arithmetic');
eq(t1.Domestic.count,2,'T1 domestic has arrival and departure');
eq(t1.International.value,null,'missing international remains null');
eq(t1.International.count,0,'missing international has no source components');
eq(app.cellText(t1.Total),'486,638*','partial total is marked');
eq(tbit.Domestic.value,127769,'TBIT December domestic');
eq(tbit.International.value,877519,'TBIT December international');
eq(app.aggregate(data,state(2023)).months.length,10,'2023 has ten reporting months');
eq(data.rows.filter(row=>row.terminal==='TBIT West Gates')[0].date.toISOString().slice(0,7),'2021-05','West Gates entry date');
eq(data.rows.filter(row=>row.terminal==='Imperial Terminal').at(-1).date.toISOString().slice(0,7),'2016-04','Imperial last observed month');
// Changing a scale must not alter data or aggregation.
eq(total(app.aggregate(data,{...state(2022),scale:'independent'})),total(view),'scale preserves counts');
vm.runInContext(read('learn/answers.js'),context);
const answers = context.window.LAX_CHOICES;
const points=values=>values.map((value,i)=>({date:new Date(Date.UTC(2022,i,1)),Domestic:{value}}));
const fixture=points([null,0,30,30,10]);
eq(answers.peakMonths(fixture,'Domestic').map(p=>fixture.indexOf(p)).join(), '2,3', 'both tied peaks returned');
eq(answers.peakMonths(points([null,null]),'Domestic').length,0,'all missing: no peak');
eq(answers.peakMonths(points([0,0]),'Domestic').length,2,'observed zero can be a peak');
eq(answers.peakMonths([],'Domestic').length,0,'empty series has no peak');
const panels=[{terminal:'A',reported:20},{terminal:'B',reported:80},{terminal:'C',reported:40}];
eq(answers.orderPanels(panels,'volume').map(p=>p.terminal).join(),'B,C,A','descending volume');
eq(panels.map(p=>p.terminal).join(),'A,B,C','input order preserved');
eq(answers.orderPanels(panels,'terminal').map(p=>p.terminal).join(),'A,B,C','terminal order restored');
const exercise=app.aggregate(data,{...state(2022,'Domestic'),terminals:['T1','T2','T6','TBIT']});
for(const panel of exercise.panels){
  // Source-string calculation checks the answer independently of the plotted series.
  const monthly=Array.from({length:12},(_,i)=>source.filter(row=>row.terminal===panel.terminal&&row.reportperiod.startsWith(`2022-${String(i+1).padStart(2,'0')}`)&&row.domestic_international==='Domestic').reduce((n,row)=>n+Number(row.passenger_count),0));
  const maximum=Math.max(...monthly),expected=monthly.flatMap((n,i)=>n===maximum?[i]:[]);
  eq(answers.peakMonths(panel.values,'Domestic').map(p=>p.date.getUTCMonth()).join(),expected.join(),`${panel.terminal} source-derived peaks`);
  eq(panel.reported,monthly.reduce((a,b)=>a+b,0),`${panel.terminal} source-derived annual total`);
}
eq(total(exercise),20597147,'four-terminal domestic total unchanged');
eq(answers.orderPanels(exercise.panels,'volume').map(p=>p.terminal).join(),'T2,T1,T6,TBIT','actual annual ranking');
vm.runInContext(read('learn/choices.js'),context);
eq(context.window.LAX_CHOICES.peakMonths(fixture,'Domestic').length,0,'starter leaves peak task unfinished');
eq(context.window.LAX_CHOICES.orderPanels(panels,'volume').map(p=>p.terminal).join(),'A,B,C','starter leaves sorting task unfinished');
console.log(`PASS: ${checks} checks. Source totals, peak months, missing values, ties and panel ordering verified.`);

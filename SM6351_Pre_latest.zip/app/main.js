(() => {
  const app=window.LAX, $=id=>document.getElementById(id);
  let data,view,chart,monthIndex=59;
  let currentPage, pageAnimation;
  const reducedMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
  let state={start:2018,end:2022,direction:'All',traffic:'Both',scale:'shared',sort:'terminal'};
  const titles={overview:'Overview',explore:'Visualization',walkthrough:'Implementation',practice:'Exercises'};
  function showPage(page,scroll=true) {
    const legacyPages={demo:'explore',build:'walkthrough',interact:'explore',local:'overview',notes:'overview'};
    page=legacyPages[page]||page;
    if (!titles[page]) page='overview';
    const changed=currentPage!==undefined&&currentPage!==page;
    pageAnimation?.cancel();
    document.querySelector('.site').classList.toggle('is-inner-page',page!=='overview');
    document.querySelector('.site').classList.toggle('is-workspace',page==='practice');
    document.querySelectorAll('[data-section]').forEach(section=>section.hidden=section.dataset.section!==page);
    document.querySelectorAll('[data-page]').forEach(button=>{
      button.classList.toggle('active',button.dataset.page===page);
      if(button.dataset.page===page) button.setAttribute('aria-current','page');else button.removeAttribute('aria-current');
    });
    if(scroll) document.querySelector('.site-main').scrollTo({top:0,behavior:'instant'});
    if(page==='walkthrough') app.showLesson?.(app.currentLesson||1);
    const activeSection=document.querySelector('[data-section="'+page+'"]');
    if(changed&&!reducedMotion.matches&&activeSection?.animate){
      pageAnimation=activeSection.animate([
        {opacity:0.35,transform:'translateY(5px)'},
        {opacity:1,transform:'translateY(0)'}
      ],{duration:180,easing:'cubic-bezier(0.2,0.7,0.3,1)'});
    }
    currentPage=page;
  }
  function navigate(page){if(location.hash==='#'+page)showPage(page);else location.hash=page;}
  document.querySelectorAll('[data-page]').forEach(button=>button.addEventListener('click',()=>navigate(button.dataset.page)));
  document.querySelectorAll('[data-go]').forEach(button=>button.addEventListener('click',()=>navigate(button.dataset.go)));
  window.addEventListener('hashchange',()=>showPage(location.hash.slice(1)));
  showPage(location.hash.slice(1),false);
  function syncForm(){for(const [key,value] of Object.entries(state)){const el=$('explorer-controls').elements.namedItem(key);if(el)el.value=value;}}
  function syncMonthControls(){
    const selected=view.months[monthIndex],year=selected.getUTCFullYear();
    const yearSelect=$('read-year'),monthSelect=$('read-month');
    const years=[...new Set(view.months.map(date=>date.getUTCFullYear()))];
    yearSelect.replaceChildren(...years.map(value=>{
      const option=document.createElement('option');option.value=value;option.textContent=value;return option;
    }));
    yearSelect.value=year;
    const monthDates=view.months.filter(date=>date.getUTCFullYear()===year);
    monthSelect.replaceChildren(...monthDates.map(date=>{
      const option=document.createElement('option'),month=date.getUTCMonth();
      option.value=month;option.dataset.en=d3.utcFormat('%B')(date);option.dataset.zh=`${month+1}月`;
      option.textContent=app.chinese()?option.dataset.zh:option.dataset.en;return option;
    }));
    monthSelect.value=selected.getUTCMonth();
    $('month-prev').disabled=monthIndex===0;
    $('month-next').disabled=monthIndex===view.months.length-1;
    $('selected-month').textContent=app.monthLabel(selected);
  }
  function selectMonth(index){
    monthIndex=Math.max(0,Math.min(view.months.length-1,Number(index)));
    syncMonthControls();chart.setMonth(monthIndex);
    const tbody=$('month-values');tbody.replaceChildren();
    for(const panel of view.panels){
      const p=panel.values[monthIndex];
      const tr=document.createElement('tr');
      const cells=view.series.map(key=>p[key]);
      const selected={value:cells.every(cell=>cell.value===null)?null:d3.sum(cells,cell=>cell.value??0),count:d3.sum(cells,cell=>cell.count),expected:d3.sum(cells,cell=>cell.expected)};
      [app.label(panel.terminal),app.cellText(p.Domestic),app.cellText(p.International),app.cellText(selected)].forEach(text=>{const cell=document.createElement('td');cell.textContent=text;tr.append(cell);});tbody.append(tr);
    }
  }
  function renderExplorer(){
    const prior=view?.months[monthIndex];syncForm();view=app.aggregate(data,state);
    const found=prior?view.months.findIndex(date=>+date===+prior):-1;monthIndex=found<0?view.months.length-1:found;
    const empty=view.panels.filter(panel=>!panel.hasData);
    const shown=$('show-empty-categories').checked?view.panels:view.panels.filter(panel=>panel.hasData);
    chart=app.drawCharts($('explore-charts'),{...view,panels:shown},{onMonth:selectMonth,monthIndex,coverage:true});
    $('empty-category-note').hidden=!empty.length;
    if(empty.length)app.bilingual($('empty-category-note'),`此时段无记录：${empty.map(panel=>app.label(panel.terminal)).join('、')}。可在更多选项中显示。`,`No records in this period: ${empty.map(panel=>app.label(panel.terminal)).join(', ')}. Enable “Show categories without records” to include them.`);
    $('explore-range').textContent=`${app.monthLabel(view.months[0])} — ${app.monthLabel(view.months.at(-1))} · ${view.months.length} ${app.chinese()?'个月':'months'} · ${app.directionLabel[state.direction]}`;
    const legend=$('explore-legend');legend.replaceChildren();view.series.forEach(type=>{const span=document.createElement('span'),line=document.createElement('i');line.className=type.toLowerCase();span.append(line,document.createTextNode(app.trafficLabel[type]));legend.append(span);});
    app.bilingual($('scale-explanation'),state.scale==='shared'?'共享纵轴：所有图使用相同上限，可比较客流大小。':'独立纵轴：每张图使用自己的上限，用于看各自的变化。',state.scale==='shared'?'Shared axes: all charts use the same upper limit. Compare passenger counts across terminals.':'Independent axes: each chart uses its own upper limit. Compare trends within each chart.');
    $('scale-explanation').classList.toggle('warning',state.scale==='independent');
    const active=view.panels.filter(panel=>panel.hasData),total=d3.sum(active,panel=>panel.reported);
    app.bilingual($('explore-status'),`所选范围内，${active.length} 个航站楼类别有记录，${view.panels.length-active.length} 个无记录；已报告合计 ${app.number(total)} 人次。`,`Selected period: ${active.length} terminal categories with records, ${view.panels.length-active.length} without; ${app.number(total)} reported movements.`);
    const top=[...active].sort((a,b)=>b.reported-a.reported)[0];
    app.bilingual($('finding-title'),top?`客流合计最高：${app.code(top.terminal)}`:'所选范围无记录',top?`Largest reported total: ${app.code(top.terminal)}`:'No records in this selection');
    app.bilingual($('finding-text'),top?`所选 ${view.months.length} 个月共记录 ${app.number(top.reported)} 人次，其中 ${top.coverage} 个月的到达与出发记录齐全。排序按已报告人次计算。`:'无记录不代表客流为零。',top?`${app.number(top.reported)} reported movements over ${view.months.length} selected months; ${top.coverage} months have all expected arrival and departure records. Ranking is based on reported movements.`:'No records does not mean zero traffic.');
    selectMonth(monthIndex);
  }
  window.addEventListener('lax-language-change',()=>{
    document.querySelectorAll('#from-year option,#to-year option').forEach(option=>{
      const year=Number(option.value);
      option.textContent=`${year}${data?.completeYears.includes(year)?'':(app.chinese()?' · 不完整':' · partial')}`;
    });
    if(data&&view)renderExplorer();
  });
  app.ready=(async()=>{
    try{
      data=await app.loadData();app.data=data;
      // Use actual source rows for the opening worked example.
      const example=data.rows.filter(row=>row.terminal==='T1'&&row.date.getUTCFullYear()===2022&&row.date.getUTCMonth()===11&&row.traffic==='Domestic');
      const exampleBody=$('source-example-rows');exampleBody.replaceChildren();
      for(const row of [...example].sort((a,b)=>a.direction.localeCompare(b.direction))){
        const tr=document.createElement('tr');
        for(const value of ['2022-12','T1',row.direction,row.traffic,app.number(row.value)]){const td=document.createElement('td');td.textContent=value;tr.append(td);}exampleBody.append(tr);
      }
      const arrival=example.find(row=>row.direction==='Arrival').value,departure=example.find(row=>row.direction==='Departure').value;
      $('source-example-sum').textContent=`${app.number(arrival)} + ${app.number(departure)} = ${app.number(arrival+departure)}`;
      const exampleView=app.aggregate(data,{start:2022,end:2022,direction:'All',traffic:'Domestic',scale:'shared',sort:'terminal',terminals:['T1']});
      app.drawCharts($('source-example-chart'),exampleView,{monthIndex:11,showMonth:true,interactive:false});

      for(const id of ['from-year','to-year'])for(const year of data.years){const option=document.createElement('option');option.value=year;option.textContent=`${year}${data.completeYears.includes(year)?'':(app.chinese()?' · 不完整':' · partial')}`;$(id).append(option);}
      app.connectControls($('explorer-controls'),state,renderExplorer);
      $('reset-explorer').addEventListener('click',()=>{$('show-empty-categories').checked=false;Object.assign(state,{start:2018,end:2022,direction:'All',traffic:'Both',scale:'shared',sort:'terminal'});monthIndex=59;view=null;renderExplorer();});
      $('show-empty-categories').addEventListener('change',renderExplorer);
      $('read-year').addEventListener('change',event=>{
        const year=Number(event.target.value),month=view.months[monthIndex].getUTCMonth();
        const available=view.months.filter(date=>date.getUTCFullYear()===year);
        // Preserve the month if it exists; partial years stop at their last available month.
        const chosen=available.find(date=>date.getUTCMonth()===month)||available.at(-1);
        selectMonth(view.months.indexOf(chosen));
      });
      $('read-month').addEventListener('change',event=>{
        const year=Number($('read-year').value),month=Number(event.target.value);
        selectMonth(view.months.findIndex(date=>date.getUTCFullYear()===year&&date.getUTCMonth()===month));
      });
      $('month-prev').addEventListener('click',()=>selectMonth(monthIndex-1));
      $('month-next').addEventListener('click',()=>selectMonth(monthIndex+1));
      renderExplorer();app.applyLanguage(app.chinese(),false);return data;
    }catch(error){
      const message=`Data could not load. Serve the complete project through a local web server. ${error.message}`;
      $('explore-status').textContent=message;throw error;
    }
  })();
})();

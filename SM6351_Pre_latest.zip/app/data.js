/* Shared data pipeline. Used by the website, five steps and local exercises. */
window.LAX = window.LAX || {};
(() => {
  const app = window.LAX;
  // The one-file edition embeds the same source files for opening without a server.
  app.readText = async path => {
    const key = path.replace(/^(\.\.\/|\.\/)+/, '');
    if (window.LAX_BUNDLE && key in window.LAX_BUNDLE) return window.LAX_BUNDLE[key];
    const response = await fetch(path);
    if (!response.ok) throw new Error(`Missing ${path}`);
    return response.text();
  };
  app.order = ['T1','T2','T3','T4','T5','T6','T7','T8','TBIT','TBIT West Gates','Imperial Terminal','Miscellaneous Terminal'];
  app.names = {TBIT:'Tom Bradley International','TBIT West Gates':'West Gates','Imperial Terminal':'Imperial Terminal','Miscellaneous Terminal':'Miscellaneous Terminal'};
  app.label = terminal => app.names[terminal] || `Terminal ${terminal.slice(1)}`;
  app.code = terminal => ({'TBIT West Gates':'WEST','Imperial Terminal':'IMP','Miscellaneous Terminal':'MISC'}[terminal] || terminal);
  app.trafficLabel={Domestic:'Domestic',International:'International',Total:'Total'};
  app.trafficZh={Domestic:'国内',International:'国际',Total:'合计'};
  app.directionLabel={All:'Arrivals + departures',Arrival:'Arrivals',Departure:'Departures'};
  app.scaleLabel={shared:'Shared',independent:'Independent'};
  app.colors = {Domestic:'#2865bf',International:'#c27932',Total:'#173f94'};
  app.number = value => value == null ? 'No record' : d3.format(',')(value);
  app.monthLabel = d3.utcFormat('%b %Y');
  app.short = value => value >= 1e6 ? `${+(value/1e6).toFixed(1)}m` : value >= 1000 ? `${+(value/1000).toFixed(0)}k` : `${value}`;
  app.parseRows = source => {
    const unique = new Map();
    let invalid = 0, duplicates = 0;
    // [lesson:parse]
    const parseMonth = d3.utcParse('%Y-%m');
    function readFields(row) {
      const date = parseMonth((row.reportperiod || '').slice(0, 7));
      const text = (row.passenger_count ?? '').trim();
      const value = text === '' ? NaN : Number(text);
      return { date, value };
    }
    // [/lesson:parse]
    for (const row of source) {
      const { date, value } = readFields(row);
      if (!date || !Number.isFinite(value) || value < 0 || !row.terminal ||
          !['Arrival','Departure'].includes(row.arrival_departure) ||
          !['Domestic','International'].includes(row.domestic_international)) { invalid++; continue; }
      const key = [row.reportperiod.slice(0,7),row.terminal,row.arrival_departure,row.domestic_international].join('|');
      const record = {date, terminal:row.terminal, direction:row.arrival_departure, traffic:row.domestic_international, value, extracted:row.dataextractdate};
      if (unique.has(key)) duplicates++;
      if (!unique.has(key) || record.extracted > unique.get(key).extracted) unique.set(key,record);
    }
    const rows = [...unique.values()].sort((a,b) => a.date-b.date);
    if (!rows.length) throw new Error('No valid passenger records. Check the CSV file.');
    const extent = d3.extent(rows, row => row.date);
    const months = d3.utcMonth.range(extent[0], d3.utcMonth.offset(extent[1],1));
    const years = [...new Set(rows.map(row => row.date.getUTCFullYear()))].sort(d3.ascending);
    const yearMonths = d3.rollup(rows, values => new Set(values.map(row => +row.date)).size, row => row.date.getUTCFullYear());
    return {rows, months, extent, years, completeYears:years.filter(year => yearMonths.get(year) === 12),
      terminals:[...new Set(rows.map(row => row.terminal))].sort((a,b) => app.order.indexOf(a)-app.order.indexOf(b)),
      sourceCount:source.length, invalid, duplicates};
  };
  app.loadData = async (url='data/lax-passengers.csv') => app.parseRows(d3.csvParse(await app.readText(url)));
  app.seriesFor = traffic => traffic === 'Both' ? ['Domestic','International'] : [traffic];
  app.aggregate = (data, state, seriesFor=app.seriesFor) => {
    const months = data.months.filter(date => date.getUTCFullYear() >= state.start && date.getUTCFullYear() <= state.end);
    const rows = data.rows.filter(row => row.date.getUTCFullYear() >= state.start && row.date.getUTCFullYear() <= state.end && (state.direction === 'All' || row.direction === state.direction));
    const series = seriesFor(state.traffic);
    if (!Array.isArray(series) || !series.length || new Set(series).size !== series.length || series.some(key => !['Domestic','International','Total'].includes(key))) throw new Error('series() must return distinct valid traffic names in an array.');
    if (series.includes('Total') && series.length > 1) throw new Error('Use Total on its own to avoid counting traffic twice.');
    const expected = state.direction === 'All' ? 2 : 1;
    // [lesson:group]
    const grouped = d3.group(rows,
      row => row.terminal,
      row => +row.date,
      row => row.traffic);
    function sumCell(terminal, date, traffic) {
      const records = grouped.get(terminal)?.get(+date)?.get(traffic) || [];
      return {
        value: records.length ? d3.sum(records, row => row.value) : null,
        count: records.length,
        expected
      };
    }
    // [/lesson:group]
    let panels = data.terminals.map(terminal => {
      const values = months.map(date => {
        const Domestic = sumCell(terminal,date,'Domestic');
        const International = sumCell(terminal,date,'International');
        const count = Domestic.count + International.count;
        const Total = {value:count ? (Domestic.value ?? 0)+(International.value ?? 0) : null, count, expected:expected*2};
        return {date,Domestic,International,Total};
      });
      const reported = d3.sum(values, point => d3.sum(series,key => point[key].value ?? 0));
      const hasData = values.some(point => series.some(key => point[key].value !== null));
      const coverage = values.filter(point => series.every(key => point[key].count === point[key].expected)).length;
      return {terminal,values,reported,hasData,coverage};
    });
    if (state.terminals) panels = panels.filter(panel => state.terminals.includes(panel.terminal));
    if (state.sort === 'volume') panels.sort((a,b) => b.reported-a.reported);
    return {months,panels,series,expected,state};
  };
  app.cellText = cell => cell.value === null ? 'No record' : `${app.number(cell.value)}${cell.count < cell.expected ? '*' : ''}`;
})();

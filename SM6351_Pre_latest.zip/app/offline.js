/* Runs only in the self-contained edition. All chart and exercise code stays shared. */
(() => {
  if (!window.LAX_BUNDLE) return;
  const files=window.LAX_BUNDLE,app=window.LAX;
  const script=source=>'<script>'+source.replace(/<\/script/gi,'<\\/script')+'</script>';
  const resolve=(base,path)=>{
    const parts=base.split('/').slice(0,-1);
    for(const part of path.split('/')){if(part==='..')parts.pop();else if(part!=='.')parts.push(part);}
    return parts.join('/');
  };
  app.bundlePage=path=>{
    let html=files[path],scripts=[];
    if(!html)throw new Error('Page is not included: '+path);
    html=html.replace(/<link\b[^>]*href="([^"]+\.css)"[^>]*>/g,(_,src)=>'<style>'+files[resolve(path,src)]+'</style>');
    html=html.replace(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/g,(_,src)=>{scripts.push(files[resolve(path,src)]);return '';});
    const prelude=script('window.LAX_BUNDLE='+JSON.stringify(files).replace(/</g,'\\u003c')+';');
    return html.replace('</body>',()=>prelude+scripts.map(script).join('')+'</body>');
  };
  document.addEventListener('click',event=>{
    const a=event.target.closest('a');if(!a)return;
    const path=a.getAttribute('href').split('#')[0];
    if(!path||!(path in files))return;
    event.preventDefault();
    const content=path.endsWith('.html')?app.bundlePage(path):files[path];
    const url=URL.createObjectURL(new Blob([content],{type:path.endsWith('.html')?'text/html;charset=utf-8':'text/plain;charset=utf-8'}));
    const link=document.createElement('a');link.href=url;
    if(a.hasAttribute('download')||!path.endsWith('.html'))link.download=path.split('/').at(-1);
    else{link.target='_blank';link.rel='noopener';}
    link.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
  });
})();

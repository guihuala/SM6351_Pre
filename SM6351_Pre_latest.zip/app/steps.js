(async()=>{
  const app=window.LAX,step=Number(document.body.dataset.step),root=document.getElementById('step-result');
  try{
    const data=await app.loadData('../data/lax-passengers.csv');
    const example=data.rows.filter(row=>row.terminal==='T1'&&row.date.getUTCFullYear()===2022&&row.date.getUTCMonth()===11&&row.traffic==='Domestic');
    if(step===1){
      const intro=document.createElement('p');intro.className='small muted';intro.textContent=`${app.number(data.sourceCount)} rows · ${data.months.length} months · ${data.invalid} invalid · ${data.duplicates} duplicates`;root.append(intro);
      const wrap=document.createElement('div');wrap.className='table-scroll';const table=document.createElement('table');table.innerHTML='<thead><tr><th>Month</th><th>Terminal</th><th>Movement</th><th>Traffic</th><th>Count</th></tr></thead>';const body=document.createElement('tbody');
      for(const row of example){const tr=document.createElement('tr');[app.monthLabel(row.date),row.terminal,app.directionLabel[row.direction],app.trafficLabel[row.traffic],app.number(row.value)].forEach(value=>{const td=document.createElement('td');td.textContent=value;tr.append(td);});body.append(tr);}table.append(body);wrap.append(table);root.append(wrap);
      const note=document.createElement('p');note.className='note';app.bilingual(note,'这两行来自 CSV，日期已转成 Date，人次已转成数字。','These two CSV rows now have Date objects and numeric counts.');root.append(note);
    }else if(step===2){
      root.innerHTML='<div class="group-flow"><span>T1</span><span>Dec 2022</span><span>Domestic</span></div>';
      const values=[['Arrivals',example.find(row=>row.direction==='Arrival').value],['Departures',example.find(row=>row.direction==='Departure').value],['Monthly total',d3.sum(example,row=>row.value)]];
      const group=document.createElement('div');group.className='row-example';for(const [label,value]of values){const box=document.createElement('div');if(label==='Monthly total')box.className='sum';const span=document.createElement('span'),number=document.createElement('strong');span.textContent=label;number.textContent=app.number(value);box.append(span,number);group.append(box);}root.append(group);
      const note=document.createElement('p');note.className='note';app.bilingual(note,'T1 该月没有国际客流记录，保留为 null。','T1 has no international record for this month; its value remains null.');root.append(note);
      const aligned=app.aggregate(data,{start:2021,end:2021,direction:'All',traffic:'Domestic',scale:'shared',sort:'terminal',terminals:['T1','TBIT West Gates']});
      const months=aligned.months.filter(date=>date.getUTCMonth()>=2&&date.getUTCMonth()<=5);
      const alignment=document.createElement('section');alignment.className='month-alignment';
      const heading=document.createElement('h3');app.bilingual(heading,'统一月份','Same months');alignment.append(heading);
      const wrap=document.createElement('div');wrap.className='table-scroll';
      const table=document.createElement('table'),head=document.createElement('thead'),header=document.createElement('tr');
      const terminalHeading=document.createElement('th');app.bilingual(terminalHeading,'航站楼','Terminal');header.append(terminalHeading);
      for(const date of months){const th=document.createElement('th');th.textContent=app.monthLabel(date);header.append(th);}head.append(header);table.append(head);
      const body=document.createElement('tbody');
      for(const panel of aligned.panels){
        const tr=document.createElement('tr'),name=document.createElement('th');name.scope='row';name.textContent=app.code(panel.terminal);tr.append(name);
        for(const date of months){const point=panel.values.find(value=>+value.date===+date),td=document.createElement('td');td.className='numeric';td.textContent=point.Domestic.value===null?'—':app.cellText(point.Domestic);if(point.Domestic.value===null)td.classList.add('missing-cell');tr.append(td);}body.append(tr);
      }
      table.append(body);wrap.append(table);alignment.append(wrap);
      const alignmentNote=document.createElement('p');alignmentNote.className='note';app.bilingual(alignmentNote,'每列对应同一个月。— 表示这份 CSV 没有该记录，不是 0。','Each column is the same month. — means no record in this CSV, rather than zero.');alignment.append(alignmentNote);root.append(alignment);

    }else{
      const state={start:2022,end:2022,direction:'All',traffic:'Both',scale:'shared',sort:'terminal',terminals:['T1','TBIT']};
      const controls=document.createElement('form');controls.className='controls';controls.innerHTML='<label class="field"><span>Scale</span><select name="scale"><option value="shared">Shared</option><option value="independent">Independent</option></select></label><label class="field"><span>Traffic</span><select name="traffic"><option value="Both">Both</option><option value="Domestic">Domestic</option><option value="International">International</option></select></label>';
      if(step===5)root.append(controls);
      const flow=document.createElement('div');flow.className='lesson-state-flow';
      const flowValues={};
      for(const [key,en,zh]of [['choose','Choose','选择'],['state','State','状态'],['result','Result','结果']]){
        const item=document.createElement('div'),heading=document.createElement('span'),value=document.createElement('strong');app.bilingual(heading,zh,en);item.append(heading,value);flow.append(item);flowValues[key]=value;
      }
      if(step===5)root.append(flow);
      const label=document.createElement('p');label.className='small muted';label.textContent='2022 · Arrivals + departures · Shared axes';root.append(label);
      const grid=document.createElement('div');grid.className='chart-grid pair';root.append(grid);
      const bar=document.createElement('div');bar.className='month-navigation';
      const monthLabel=document.createElement('span');app.bilingual(monthLabel,'月份','Month');
      const previous=document.createElement('button'),next=document.createElement('button'),picker=document.createElement('select'),out=document.createElement('output');
      previous.type=next.type='button';previous.textContent='‹';next.textContent='›';
      previous.setAttribute('aria-label','Previous month');next.setAttribute('aria-label','Next month');picker.setAttribute('aria-label','Month');
      for(let month=0;month<12;month++){
        const option=document.createElement('option');option.value=month;
        option.dataset.en=d3.utcFormat('%B')(new Date(Date.UTC(2022,month,1)));option.dataset.zh=`${month+1}月`;
        option.textContent=app.chinese()?option.dataset.zh:option.dataset.en;picker.append(option);
      }
      bar.append(monthLabel,previous,picker,next,out);if(step===5)root.append(bar);
      let chart,selectedIndex=11;
      const syncMonth=index=>{
        selectedIndex=Math.max(0,Math.min(11,Number(index)));picker.value=selectedIndex;
        previous.disabled=selectedIndex===0;next.disabled=selectedIndex===11;
        out.textContent=app.monthLabel(new Date(Date.UTC(2022,selectedIndex,1)));
      };
      const selectMonth=index=>{syncMonth(index);chart.setMonth(selectedIndex);};
      const render=()=>{
        const view=app.aggregate(data,state);chart=app.drawCharts(grid,view,{axesOnly:step===3,monthIndex:selectedIndex,onMonth:syncMonth});
        label.textContent=`2022 · Arrivals + departures · ${app.scaleLabel[state.scale]} · ${view.series.map(key=>app.trafficLabel[key]).join(' / ')}`;
        if(step===5){
          const trafficZh={Both:'国内 + 国际',Domestic:'国内',International:'国际'};
          app.bilingual(flowValues.choose,`${state.scale==='shared'?'共享':'独立'} · ${trafficZh[state.traffic]}`,`${app.scaleLabel[state.scale]} · ${state.traffic}`);
          const stateText=`scale: "${state.scale}", traffic: "${state.traffic}"`;flowValues.state.textContent=stateText;
          const reported=d3.sum(view.panels,panel=>panel.reported),limits=chart.maxima.map(app.number).join(' / ');
          app.bilingual(flowValues.result,`纵轴上限 ${limits}；合计 ${app.number(reported)} 人次`,`Axis limits: ${limits}; total: ${app.number(reported)} movements`);
        }
        syncMonth(selectedIndex);
      };
      app.connectControls(controls,state,render);
      picker.addEventListener('change',event=>selectMonth(event.target.value));previous.addEventListener('click',()=>selectMonth(selectedIndex-1));next.addEventListener('click',()=>selectMonth(selectedIndex+1));render();
    }
  }catch(error){root.className='error-panel';root.textContent=`Example could not load. Serve the project locally. ${error.message}`;}
})();

// Keep embedded examples the height of their content.
if(parent!==window)new ResizeObserver(()=>parent.postMessage({type:"lax-step-height",height:Math.ceil(document.body.getBoundingClientRect().height)},"*")).observe(document.body);

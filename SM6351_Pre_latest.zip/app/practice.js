(() => {
  const app=window.LAX,$=id=>document.getElementById(id),frame=$('exercise-preview');
  const editors={peak:$('peak-editor'),sort:$('sort-editor')};
  let assets,starter,runNumber=0,timer;
  let attempted=false,lastOptions={sort:'terminal',peaks:true};
  let activeFile='js',activeTask='peak';
  const fileDetails={
    js:{name:'choices.js',en:'Editable excerpt',zh:'可编辑片段'},
    html:{name:'index.html',en:'Read-only excerpt',zh:'只读片段'},
    css:{name:'app.css',en:'Read-only excerpt',zh:'只读片段'},
    data:{name:'lax-passengers.csv',en:'Read only',zh:'只读'}
  };
  function updateLines(){
    const numbers=$('workspace-lines');
    if(numbers)numbers.textContent=Array.from({length:editors[activeTask].value.split('\n').length},(_,i)=>i+1).join('\n');
  }
  function selectFile(file){
    if(!fileDetails[file])return;
    activeFile=file;
    document.querySelectorAll('[data-workspace-file]').forEach(button=>{
      const selected=button.dataset.workspaceFile===file;
      button.classList.toggle('active',selected);
      if(button.getAttribute('role')==='tab')button.setAttribute('aria-selected',String(selected));
      else button.setAttribute('aria-pressed',String(selected));
    });
    document.querySelectorAll('[data-workspace-panel]').forEach(panel=>panel.hidden=panel.dataset.workspacePanel!==file);
    if($('workspace-filename'))$('workspace-filename').textContent=fileDetails[file].name;
    if($('workspace-file-state'))app.bilingual($('workspace-file-state'),fileDetails[file].zh,fileDetails[file].en);
  }
  function selectTask(task,focus=false){
    if(!editors[task])return;
    activeTask=task;selectFile('js');
    document.querySelectorAll('[data-workspace-task]').forEach(button=>{
      const selected=button.dataset.workspaceTask===task;
      button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));
    });
    document.querySelectorAll('[data-editor-task]').forEach(panel=>panel.hidden=panel.dataset.editorTask!==task);
    if($('workspace-selected-task'))app.bilingual($('workspace-selected-task'),task==='peak'?'任务一：最高月份':'任务二：客流排序',task==='peak'?'Task 1 · Peak months':'Task 2 · Panel order');
    updateLines();if(focus)editors[task].focus();
  }
  document.querySelectorAll('[data-workspace-file]').forEach(button=>button.addEventListener('click',()=>selectFile(button.dataset.workspaceFile)));
  document.querySelectorAll('[data-workspace-task]').forEach(button=>button.addEventListener('click',()=>{
    selectTask(button.dataset.workspaceTask);
    if(button.hasAttribute('data-workspace-jump')){
      $('live-workspace')?.scrollIntoView({behavior:'smooth',block:'start'});
      editors[activeTask].focus({preventScroll:true});
    }
  }));
  function loadReferences(){
    // Show only the preview root and two relevant style rules, never full files.
    if($('workspace-html-code'))$('workspace-html-code').textContent='<main id="result">\n  <!-- D3 adds the terminal charts here. -->\n</main>';
    if($('workspace-css-code')){
      const rules=['chart-card','data-line'].map(name=>{
        const match=assets.css.match(new RegExp('\\.'+name+'\\s*\\{[^}]*\\}'));
        return match?match[0].replace(/;/g,';\n  ').replace('{','{\n  ').replace(/\s*}/,'\n}'):'';
      }).filter(Boolean);
      $('workspace-css-code').textContent=rules.join('\n\n');
    }
  }
  async function loadDataSample(){
    const target=$('workspace-data-body');if(!target)return;
    const csv=await app.readText('data/lax-passengers.csv');
    const rows=d3.csvParse(csv),terminals=['T1','T2','T6','TBIT'];
    const sample=rows.filter(row=>row.reportperiod.startsWith('2022-12')&&row.domestic_international==='Domestic'&&terminals.includes(row.terminal))
      .sort((a,b)=>terminals.indexOf(a.terminal)-terminals.indexOf(b.terminal)||a.arrival_departure.localeCompare(b.arrival_departure));
    target.replaceChildren();
    for(const row of sample){
      const tr=document.createElement('tr');
      for(const value of [row.reportperiod.slice(0,7),row.terminal,row.arrival_departure,app.number(Number(row.passenger_count))]){
        const td=document.createElement('td');td.textContent=value;tr.append(td);
      }target.append(tr);
    }
    if($('workspace-data-note'))app.bilingual($('workspace-data-note'),`显示 ${sample.length} 条原始记录：2022 年 12 月国内客流。完整 CSV 共 ${app.number(rows.length)} 行。`,`${sample.length} source rows shown: December 2022 domestic traffic. The full CSV contains ${app.number(rows.length)} rows.`);
  }
  selectTask('peak');
  const status=(en,zh,error=false)=>{app.bilingual($('run-status'),zh,en);$('run-status').classList.toggle('error',error);};
  const answerExcerpts={
    peak:'return values.filter(d => d[key].value === maximum);',
    sort:'if (mode === "volume") ordered.sort((a, b) => b.reported - a.reported);'
  };
  const answerBodies={
    peak:'const maximum = d3.max(values, d => d[key].value);\n'+answerExcerpts.peak,
    sort:'const ordered = [...panels];\n'+answerExcerpts.sort+'\nreturn ordered;'
  };
  function syncAnswers(){
    document.querySelectorAll('[data-task-answer]').forEach(button=>{
      const task=button.dataset.taskAnswer,answer=$('answer-'+task);
      button.disabled=!starter||!assets||!app.data;
      const open=Boolean(answer&&!answer.hidden);
      button.setAttribute('aria-expanded',String(open));
      app.bilingual(button,'查看并填入答案','View & apply answer');
    });
  }
  document.querySelectorAll('[data-task-answer]').forEach(button=>button.addEventListener('click',()=>{
    if(!starter||!assets||!app.data)return;
    const task=button.dataset.taskAnswer,answer=$('answer-'+task);
    if(!answer||!answerExcerpts[task])return;
    const editor=editors[task];
    editor.value=answerBodies[task];
    answer.textContent=answerExcerpts[task];answer.hidden=false;
    selectTask(task);
    if(task==='peak')$('practice-peaks').checked=true;
    if(task==='sort')$('practice-sort').value='volume';
    const start=editor.value.indexOf(answerExcerpts[task]);
    editor.focus({preventScroll:true});
    editor.setSelectionRange(start,start+answerExcerpts[task].length);
    $('live-workspace')?.scrollIntoView({behavior:'smooth',block:'start'});
    run(true);
  }));
  function feedback(en,zh){if($('workspace-feedback'))app.bilingual($('workspace-feedback'),zh,en);}
  function trace(en,zh){if($('workspace-trace'))app.bilingual($('workspace-trace'),zh,en);}
  syncAnswers();
  const escapeScript=text=>text.replace(/<\/script/gi,'<\\/script');
  const source=()=>`window.LAX_CHOICES = {
  peakMonths(values, key) {
${editors.peak.value}
  },
  orderPanels(panels, mode) {
${editors.sort.value}
  }
};`;
  function run(userRun=false){
    if(!assets||!app.data)return;
    if(userRun===true){attempted=true;syncAnswers();}
    const id=++runNumber;clearTimeout(timer);status('Running…','运行中…');
    for(const i of [1,2]){app.bilingual($('task'+i+'-badge'),'检查中','Checking');$('task'+i+'-badge').classList.remove('done');}
    const options={sort:$('practice-sort').value,peaks:$('practice-peaks').checked};lastOptions=options;
    const payload=JSON.stringify({rows:app.data.rows,months:app.data.months,terminals:app.data.terminals});
    const catcher=`window.LAX_SHOW_CHINESE=${app.chinese()};window.addEventListener('error',event=>{window.laxCodeFailed=true;parent.postMessage({type:'lax-exercise',id:${id},error:event.message},'*');});`;
    const runner=`if(!window.laxCodeFailed)try{const data=${payload};data.rows.forEach(row=>row.date=new Date(row.date));data.months=data.months.map(date=>new Date(date));const result=LAX.runLesson(document.getElementById('result'),data,${JSON.stringify(options)},window.LAX_CHOICES);parent.postMessage({type:'lax-exercise',id:${id},result},'*');}catch(error){document.getElementById('result').textContent=error.message;parent.postMessage({type:'lax-exercise',id:${id},error:error.message},'*');}new ResizeObserver(()=>parent.postMessage({type:'lax-exercise-height',id:${id},height:Math.ceil(document.body.getBoundingClientRect().height)},'*')).observe(document.body);`;
    const tags=[catcher,assets.d3,assets.i18n,assets.data,assets.chart,assets.runner,source(),runner].map(code=>'<script>'+escapeScript(code)+'</script>').join('');
    frame.srcdoc=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none'"><style>${assets.css}</style></head><body class="step-body"><main id="result"></main>${tags}</body></html>`;
    timer=setTimeout(()=>{status('Preview did not finish. Check loops or reset the edits.','预览未完成，请检查循环或重置。',true);trace('Preview not updated.','预览未更新。');feedback('Check for a loop that does not end, or reset the edits.','检查是否有未结束的循环，或点击 Reset 重置。');},5000);
  }
  window.addEventListener('message',event=>{
    if(event.source!==frame.contentWindow||event.data?.id!==runNumber)return;
    if(event.data.type==='lax-exercise-height'&&Number.isFinite(event.data.height)){frame.style.height=Math.min(2400,Math.max(300,event.data.height+12))+'px';return;}
    if(event.data.type!=='lax-exercise')return;clearTimeout(timer);
    if(event.data.error){status('Code error: '+event.data.error,'代码错误：'+event.data.error,true);trace('Code did not run.','代码未运行成功。');feedback('Check the edited line for missing brackets, quotes or a return value.','检查修改行的括号、引号和返回值。');for(const i of [1,2])app.bilingual($('task'+i+'-badge'),'检查代码','Check code');return;}
    const result=event.data.result;
    for(const [i,done] of [[1,result.peakCorrect],[2,result.sortCorrect]]){app.bilingual($('task'+i+'-badge'),done?'已完成':'未完成',done?'Complete':'Incomplete');$('task'+i+'-badge').classList.toggle('done',done);}
    const count=result.peaks.reduce((n,p)=>n+p.months.length,0);
    status(`${count} peak months returned · Order: ${result.order.join(' → ')} · Total: ${app.number(result.reported)}`,`返回 ${count} 个最高月份，顺序：${result.order.join(' → ')}，合计：${app.number(result.reported)}`);
    const requested=lastOptions.sort==='volume'?'Volume':'Terminal order';
    trace(`Order: ${requested} → ${result.order.join(' → ')} · Peak labels: ${lastOptions.peaks?count:'off'}`,`所选排序：${lastOptions.sort==='volume'?'客流从高到低':'航站楼顺序'} → ${result.order.join(' → ')}，峰值标注：${lastOptions.peaks?count:'关闭'}`);
    const adviceEn=[],adviceZh=[];
    if(!result.peakCorrect){adviceEn.push('Task 1: replace return [] with the months that have the highest count.');adviceZh.push('任务一：修改 return []，返回客流最高的月份。');}
    if(!result.sortCorrect){adviceEn.push('Task 2: add the sorting line before return ordered.');adviceZh.push('任务二：在 return ordered 前加入排序语句。');}
    if(!attempted)feedback('Edit a marked line, then run the code to check it.','修改标记处，再运行代码检查。');
    else if(!adviceEn.length)feedback('Both changes work. Check the marked months and switch the order to compare.','两处修改均通过。查看峰值月份，并切换排序核对图表。');
    else feedback(adviceEn.join(' '),adviceZh.join(' '));
  });
  for(const editor of Object.values(editors)){
    editor.addEventListener('input',()=>{updateLines();status('Edited. Run changes to update the preview.','已修改，点击运行更新预览。');});
    editor.addEventListener('scroll',()=>{if($('workspace-lines')&&editor===editors[activeTask])$('workspace-lines').scrollTop=editor.scrollTop;});
    editor.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key==='Enter'){event.preventDefault();run(true);}if(event.key==='Tab'){event.preventDefault();editor.setRangeText('  ',editor.selectionStart,editor.selectionEnd,'end');updateLines();}});
  }
  $('run-code').addEventListener('click',()=>run(true));
  $('reset-code').addEventListener('click',()=>{attempted=false;for(const key of ['peak','sort']){editors[key].value=starter[key];if($('answer-'+key))$('answer-'+key).hidden=true;}syncAnswers();updateLines();run(false);});
  $('practice-sort').addEventListener('change',()=>run(false));$('practice-peaks').addEventListener('change',()=>run(false));
  $('export-code').addEventListener('click',()=>{const url=URL.createObjectURL(new Blob([source()],{type:'text/javascript'})),link=document.createElement('a');link.href=url;link.download='choices.js';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status('Exported choices.js.','已导出 choices.js。');});
  (async()=>{try{
    const paths={d3:'vendor/d3.v7.min.js',i18n:'app/i18n.js',data:'app/data.js',chart:'app/chart.js',runner:'app/lesson-runner.js',css:'app.css',starter:'learn/choices.js'};
    assets=Object.fromEntries(await Promise.all(Object.entries(paths).map(async([key,path])=>[key,await app.readText(path)])));
    starter={};for(const key of ['peak','sort']){starter[key]=assets.starter.split('// [edit:'+key+']')[1].split('// [/edit:'+key+']')[0].trim().split('\n').map(line=>line.replace(/^    /,'')).join('\n');editors[key].value=starter[key];}
    loadReferences();updateLines();await app.ready;await loadDataSample();syncAnswers();run(false);
  }catch(error){status('Exercise could not load: '+error.message,'练习未加载：'+error.message,true);}})();
})();

/* Same records and axes; only the panel layout changes. */
(() => {
  const app=window.LAX;
  const container=document.getElementById('layout-charts');
  if(!container)return;
  const terminals=['T1','T2','T3','T4','T5','T6'];
  const palette=['#356ca7','#b46c3c','#4b8673','#8a74ac','#a18b42','#667787'];
  let layout='multiples',view,yDomain;
  function render(){
    container.replaceChildren();
    container.className=layout==='overlay'?'layout-overlay':'layout-chart-grid';
    container.dataset.layout=layout;
    container.dataset.yDomain=yDomain.join(',');
    document.querySelectorAll('[data-layout-choice]').forEach(button=>{
      const selected=button.dataset.layoutChoice===layout;
      button.setAttribute('aria-pressed',String(selected));
      button.classList.toggle('active',selected);
    });
    const groups=layout==='overlay'?[view.panels]:view.panels.map(panel=>[panel]);
    for(const panels of groups){
      const overlay=layout==='overlay',width=overlay?1000:330,height=overlay?260:180;
      const margin={left:48,right:18,top:16,bottom:31};
      const x=d3.scaleUtc().domain(d3.extent(view.months)).range([margin.left,width-margin.right]);
      const y=d3.scaleLinear().domain(yDomain).range([height-margin.bottom,margin.top]);
      const article=d3.select(container).append('article').attr('class','layout-panel');
      if(!overlay)article.append('h4').attr('class','layout-panel-title').text(panels[0].terminal);
      const label=overlay?'Six LAX terminals, domestic passenger movements in 2019, shared axes':`${panels[0].terminal}, domestic passenger movements in 2019, shared axes`;
      const svg=article.append('svg').attr('viewBox',`0 0 ${width} ${height}`).attr('role','img').attr('aria-label',label);
      svg.append('g').attr('class','axis y-axis').attr('transform',`translate(${margin.left},0)`)
        .call(d3.axisLeft(y).ticks(3).tickFormat(app.short).tickSize(-(width-margin.left-margin.right)))
        .call(group=>group.select('.domain').remove());
      svg.append('g').attr('class','axis x-axis').attr('transform',`translate(0,${height-margin.bottom})`)
        .call(d3.axisBottom(x).ticks(d3.utcMonth.every(3)).tickFormat(d3.utcFormat('%b')).tickSizeOuter(0));
      for(const panel of panels){
        const color=palette[terminals.indexOf(panel.terminal)];
        const line=d3.line().defined(point=>point.Domestic.value!==null)
          .x(point=>x(point.date)).y(point=>y(point.Domestic.value));
        svg.append('path').datum(panel.values).attr('class','layout-data-line')
          .attr('data-terminal',panel.terminal).attr('d',line).attr('fill','none')
          .attr('stroke',color).attr('stroke-width',overlay?2.4:2.2)
          .attr('stroke-linecap','round').attr('stroke-linejoin','round');
        svg.append('g').selectAll('circle').data(panel.values.filter(point=>point.Domestic.value!==null))
          .join('circle').attr('cx',point=>x(point.date)).attr('cy',point=>y(point.Domestic.value))
          .attr('r',overlay?2.3:2).attr('fill',color);
      }
    }
    app.bilingual(document.getElementById('layout-note'),
      layout==='overlay'?'六个航站楼的折线放在同一张图中。':'每个航站楼单独一张图，线条不再相互重叠。',
      layout==='overlay'?'The six terminal lines share one plotting area.':'Each terminal has its own panel, so its line does not overlap the others.');
  }
  (async()=>{
    try{
      const data=await app.ready;
      view=app.aggregate(data,{start:2019,end:2019,direction:'All',traffic:'Domestic',scale:'shared',sort:'terminal',terminals});
      const maximum=d3.max(view.panels,panel=>d3.max(panel.values,point=>point.Domestic.value))||1;
      // Compute the shared domain once, so both layouts retain exactly the same axes.
      yDomain=d3.scaleLinear().domain([0,maximum]).nice().domain();
      const legend=document.getElementById('layout-legend');legend.replaceChildren();
      terminals.forEach((terminal,index)=>{
        const item=document.createElement('span'),swatch=document.createElement('i');
        swatch.style.background=palette[index];item.append(swatch,document.createTextNode(terminal));legend.append(item);
      });
      app.bilingual(document.getElementById('layout-caption'),
        '2019 年 · 国内客流 · 六个航站楼 · 相同坐标轴',
        '2019 · Domestic · Six terminals · Same axes');
      document.querySelectorAll('[data-layout-choice]').forEach(button=>button.addEventListener('click',()=>{
        if(!['overlay','multiples'].includes(button.dataset.layoutChoice))return;
        layout=button.dataset.layoutChoice;render();
      }));
      render();
    }catch(error){
      app.bilingual(document.getElementById('layout-caption'),'对比图未能加载。','The comparison could not load.');
    }
  })();
})();

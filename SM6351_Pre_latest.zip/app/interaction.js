(() => {
  const app=window.LAX;
  app.connectControls = (form, state, render) => {
    // [lesson:interact]
    form.addEventListener('change', event => {
      const key = event.target.name;
      if (!key) return;
      const value = event.target.value;
      state[key] = ['start','end'].includes(key) ? Number(value) : value;
      if (state.start > state.end) {
        if (key === 'start') state.end = state.start;
        else state.start = state.end;
      }
      render(); // filter → aggregate → redraw
    });
    // [/lesson:interact]
    form.addEventListener('submit',event=>event.preventDefault());
  };
})();

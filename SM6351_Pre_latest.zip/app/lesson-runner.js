/* Same data and renderer for the online and local exercises. */
(() => {
  const app=window.LAX;
  app.runLesson=(container,data,options,choices)=>{
    const view=app.aggregate(data,{start:2022,end:2022,direction:'All',traffic:'Domestic',scale:'shared',sort:'terminal',terminals:['T1','T2','T6','TBIT']});
    const original=[...view.panels];
    const panels=choices.orderPanels([...original],options.sort||'terminal');
    if(!Array.isArray(panels)||panels.length!==original.length||new Set(panels).size!==original.length||panels.some(panel=>!original.includes(panel)))throw new Error('orderPanels must return each original panel exactly once.');
    view.panels=panels;
    container.replaceChildren();
    const caption=document.createElement('p');caption.className='small muted';
    app.bilingual(caption,'2022 年国内客流，到达与出发相加','2022 · Domestic · Arrivals + departures');
    const grid=document.createElement('div');grid.className='chart-grid pair exercise-grid';
    const order=document.createElement('p');order.className='exercise-order';
    app.bilingual(order,'顺序：'+panels.map(panel=>panel.terminal).join(' → '),'Order: '+panels.map(panel=>panel.terminal).join(' → '));
    container.append(caption,order,grid);
    app.drawCharts(grid,view,{peakMonths:choices.peakMonths,showPeaks:options.peaks!==false,showTotals:true,showMonth:true});
    // Independent behavioural checks: missing data, ties, zero and restoring order.
    let peakCorrect=false,sortCorrect=false;
    const point=value=>({Domestic:{value}});
    try{
      const fixture=[point(null),point(0),point(30),point(30),point(10)];
      const peaks=choices.peakMonths(fixture,'Domestic');
      peakCorrect=Array.isArray(peaks)&&peaks.length===2&&peaks[0]===fixture[2]&&peaks[1]===fixture[3]
        &&choices.peakMonths([point(null)],'Domestic').length===0&&choices.peakMonths([point(0)],'Domestic').length===1;
      const fixed=[{terminal:'A',reported:20},{terminal:'B',reported:80},{terminal:'C',reported:40}];
      const sorted=choices.orderPanels(fixed,'volume');
      const reset=choices.orderPanels(fixed,'terminal');
      sortCorrect=sorted.map(p=>p.terminal).join()==='B,C,A'&&reset.map(p=>p.terminal).join()==='A,B,C'&&fixed.map(p=>p.terminal).join()==='A,B,C';
    }catch{}
    const peaks=panels.map(panel=>({terminal:panel.terminal,months:choices.peakMonths(panel.values,'Domestic').map(point=>app.monthLabel(point.date))}));
    const reported=d3.sum(panels,panel=>panel.reported);
    const totals=document.createElement('p');totals.className='small muted';
    app.bilingual(totals,`四个航站楼合计：${app.number(reported)} 人次。标注和排序不改变数据。`,`Four-terminal total: ${app.number(reported)} movements. Markers and ordering do not change the counts.`);container.append(totals);
    return {peakCorrect,sortCorrect,reported,order:panels.map(p=>p.terminal),peaks};
  };
})();

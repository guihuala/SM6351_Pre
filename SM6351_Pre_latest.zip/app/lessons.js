(() => {
  const app=window.LAX,$=id=>document.getElementById(id),cache=new Map();
  const lessons=[
  {
    "title": "1. 读取数据 / Read data",
    "file": "app/data.js",
    "marker": "parse",
    "page": "01-data.html",
    "zh": "将 reportperiod 转成日期，passenger_count 转成数字。横轴使用 reportperiod。",
    "summary": "Convert reportperiod to a date and passenger_count to a number. Use reportperiod for the x-axis.",
    "words": [
      [
        "d3.utcParse",
        "将年月转成 UTC 日期。 / Parses a year and month as a UTC date."
      ],
      [
        "Number(text)",
        "将人次转成数字。 / Converts the count to a number."
      ],
      [
        "text === '' ? NaN : …",
        "保留空值，避免把空白转成 0。 / Keeps blanks from becoming zero."
      ]
    ],
    "expected": "下方为 T1 在 2022 年 12 月的两条国内客流记录。 / Two domestic records for T1 in December 2022.",
  },
  {
    "title": "2. 按月汇总 / Group and sum",
    "file": "app/data.js",
    "marker": "group",
    "page": "02-group.html",
    "zh": "按航站楼、月份和客流类别分组，将到达与出发人次相加。所有图按同一组月份排列，缺失值保留为 null。",
    "summary": "Group by terminal, month and traffic type, then sum arrivals and departures. Align all panels to the same months; keep missing values as null.",
    "words": [
      [
        "d3.group",
        "按字段建立分组。 / Groups records by the specified fields."
      ],
      [
        "+row.date",
        "用时间戳作为月份键。 / Uses a timestamp as the month key."
      ],
      [
        "d3.sum",
        "加总已记录的人次。 / Adds the recorded passenger counts."
      ],
      [
        "null",
        "该类别没有记录。 / No record for this category."
      ]
    ],
    "expected": "T1 月度合计为 486,638；下表显示不同航站楼的月份对齐。 / T1 totals 486,638 movements. The table aligns months across terminals.",
  },
  {
    "title": "3. 设置坐标轴 / Scales",
    "file": "app/chart.js",
    "marker": "scales",
    "page": "03-scale.html",
    "zh": "横轴使用月份，纵轴使用人次。共享模式下，所有图使用相同的纵轴上限。",
    "summary": "Map months to x and counts to y. Shared mode uses the same y-axis upper limit for all charts.",
    "words": [
      [
        "domain",
        "数据范围。 / Range of data values."
      ],
      [
        "range",
        "对应的屏幕坐标范围。 / Corresponding screen coordinates."
      ],
      [
        "d3.scaleUtc",
        "把月份映射到横坐标。 / Maps months to x positions."
      ],
      [
        "d3.scaleLinear",
        "把人次映射到纵坐标。 / Maps counts to y positions."
      ]
    ],
    "expected": "此步只画 T1 和 TBIT 的坐标轴，尚未加入折线。 / Axes for T1 and TBIT, before adding lines.",
  },
  {
    "title": "4. 绘制折线 / Lines",
    "file": "app/chart.js",
    "marker": "line",
    "page": "04-draw.html",
    "zh": "按月份连接数据点。缺失月份断线，真实的 0 保留在零线上。",
    "summary": "Connect monthly points. Leave a gap for missing months; keep recorded zeros on the baseline.",
    "words": [
      [
        "d3.line()",
        "根据数据点生成 SVG 路径。 / Creates an SVG path from data points."
      ],
      [
        ".defined(…)",
        "跳过缺失点，并在该处断线。 / Skips missing points and breaks the line."
      ],
      [
        ".datum(panel.values)",
        "将当前航站楼的数据绑定给路径。 / Binds the terminal’s data to its path."
      ]
    ],
    "expected": "T1 在 2022 年没有国际客流记录，因此没有橙色线。 / T1 has no international records in 2022, so no orange line is drawn.",
  },
  {
    "title": "5. 连接控件 / Interaction",
    "file": "app/interaction.js",
    "marker": "interact",
    "page": "05-interact.html",
    "zh": "选项改变时，更新 state 并重新绘图。选择月份或点击前后按钮，同步查看两张图。",
    "summary": "A selection updates state and redraws the charts. Select a month or use the previous/next buttons to read both panels.",
    "words": [
      [
        "addEventListener('change', …)",
        "监听选择器变化。 / Listens for a changed selection."
      ],
      [
        "state[key]",
        "保存当前选项。 / Stores the current selection."
      ],
      [
        "render()",
        "重新计算并绘图。 / Recomputes and redraws the view."
      ]
    ],
    "expected": "更改纵轴或客流选项，查看状态、纵轴上限和合计如何更新。 / Change Scale or Traffic to update the state, axis limits and reported total.",
  }
];
  let serial=0;
  app.showLesson=async number=>{
    app.currentLesson=number;const lesson=lessons[number-1],ticket=++serial;
    document.querySelectorAll('[data-step]').forEach(button=>{button.classList.toggle('active',+button.dataset.step===number);button.setAttribute('aria-pressed',String(+button.dataset.step===number));});
    const title=lesson.title.split(' / ');app.bilingual($('lesson-title'),title[0],title[1]);app.bilingual($('lesson-summary'),lesson.zh,lesson.summary);
    if($('lesson-file'))$('lesson-file').textContent=lesson.file;$('snippet-path').textContent=lesson.file;
    const expected=lesson.expected.split(' / ');app.bilingual($('lesson-expected'),expected[0],expected.slice(1).join(' / ')||expected[0]);if($('lesson-reproduce')){$('lesson-reproduce').hidden=true;$('lesson-reproduce').textContent='';}
    const list=$('lesson-keywords');list.replaceChildren();for(const [key,text]of lesson.words){const item=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=key;const parts=text.split(' / ');app.bilingual(dd,parts[0],parts.slice(1).join(' / '));item.append(dt,dd);list.append(item);}
    if(window.LAX_BUNDLE) $('step-preview').srcdoc=app.bundlePage('steps/'+lesson.page);
    else $('step-preview').src='steps/'+lesson.page;
    $('open-step').href='steps/'+lesson.page;
    app.bilingual($('next-step'),number===5?'进入练习 →':'下一步 →',number===5?'Exercises →':'Next step →');
    try{if(!cache.has(lesson.file))cache.set(lesson.file,await app.readText(lesson.file));if(ticket!==serial)return;
      const source=cache.get(lesson.file),start=`// [lesson:${lesson.marker}]`,end=`// [/lesson:${lesson.marker}]`;
      const excerpt=source.split(start)[1].split(end)[0].replace(/^\n/,'').replace(/\s+$/,'');
      const lines=excerpt.split('\n'),indent=Math.min(...lines.filter(line=>line.trim()).map(line=>line.match(/^ */)[0].length));
      let snippet=lines.map(line=>line.slice(indent)).join('\n');
      if(lesson.marker==='group')snippet=snippet.split('function sumCell')[0].trim()+'\n\n'+excerpt.match(/d3.sum\(records, row => row.value\)/)[0]+';';
      if(lesson.marker==='scales')snippet=snippet.split('function makeY')[0].trim()+'\n\n'+snippet.match(/return d3.scaleLinear\(\)[\s\S]*?margin.top\]\);/)[0].replace('return ','').replace(/^ +/gm,'');
      if(lesson.marker==='line')snippet=snippet.split("svg.append('path')")[0].trim();
      $('lesson-code').textContent=snippet;
    }catch(error){$('lesson-code').textContent='Serve the project locally to load this excerpt.';}
  };
  window.addEventListener('message',event=>{if(event.source===$('step-preview').contentWindow&&event.data?.type==='lax-step-height'&&Number.isFinite(event.data.height))$('step-preview').style.height=Math.min(1800,Math.max(230,event.data.height+8))+'px';});
  document.querySelectorAll('[data-step]').forEach(button=>button.addEventListener('click',()=>app.showLesson(+button.dataset.step)));
  $('next-step').addEventListener('click',()=>app.currentLesson===5?location.hash='practice':app.showLesson((app.currentLesson||1)+1));
  $('copy-snippet').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('lesson-code').textContent);app.bilingual($('copy-snippet'),'已复制','Copied');setTimeout(()=>app.bilingual($('copy-snippet'),'复制片段','Copy excerpt'),1500);}catch{app.bilingual($('copy-snippet'),'请选中文本复制','Select and copy');}});
})();

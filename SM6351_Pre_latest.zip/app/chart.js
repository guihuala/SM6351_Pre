/* Shared D3 renderer. No data is fetched or fabricated here. */
(() => {
  const app = window.LAX;
  app.yDomain = (mode, sharedMax, panelMax) => [0, mode === 'shared' ? sharedMax : panelMax];
  app.drawCharts = (container, view, options={}) => {
    const root = d3.select(container);
    root.selectAll('*').remove();
    const width=440, height=245, margin={left:52,right:18,top:20,bottom:39};
    const series=view.series, refs=[];
    const panelMax = panel => d3.max(panel.values, point => d3.max(series, key => point[key].value)) || 1;
    const globalMax = d3.max(view.panels, panelMax) || 1;
    const domainFor = options.yDomain || app.yDomain;
    const mode = view.state.scale || 'shared';
    // [lesson:scales]
    const x = d3.scaleUtc()
      .domain(d3.extent(view.months))
      .range([margin.left, width-margin.right]);
    function makeY(panel) {
      const domain = domainFor(mode, globalMax, panelMax(panel));
      if (!Array.isArray(domain) || domain.length !== 2 || domain[0] !== 0 || !Number.isFinite(domain[1]) || domain[1] <= 0) throw new Error('yDomain() must return [0, a positive maximum].');
      return d3.scaleLinear()
        .domain(domain).nice()
        .range([height-margin.bottom, margin.top]);
    }
    // [/lesson:scales]
    for (const panel of view.panels) {
      const y = makeY(panel);
      const card = root.append('article').attr('class','chart-card');
      const top = card.append('div').attr('class','chart-card-head');
      top.append('span').attr('class','terminal-tag').text(app.code(panel.terminal));
      top.append('h3').text(app.label(panel.terminal));
      top.append('span').attr('class','axis-tag').text(`MAX ${app.short(y.domain()[1])}`);
      if (options.coverage) {
        const recorded=panel.values.filter(point=>series.some(key=>point[key].value!==null));
        const first=recorded[0]?.date,last=recorded.at(-1)?.date;
        const note=card.append('p').attr('class','coverage-note');
        if (!recorded.length || +first!==+view.months[0] || +last!==+view.months.at(-1)) {
          const range=`${app.monthLabel(recorded.length?first:view.months[0])}–${app.monthLabel(recorded.length?last:view.months.at(-1))}`;
          app.bilingual(note.node(),recorded.length?`记录范围：${range}`:`所选时段无记录：${range}`,recorded.length?`Records: ${range}`:`No records in ${range}`);
        } else note.attr('aria-hidden','true');
      }
      if(options.showTotals){const total=card.append('p').attr('class','panel-total');app.bilingual(total.node(),`全年合计：${app.number(panel.reported)} 人次`,`Annual total: ${app.number(panel.reported)}`);}
      const svg=card.append('svg').attr('viewBox',`0 0 ${width} ${height}`).attr('role','img').attr('aria-label',`${app.label(panel.terminal)}. Monthly ${series.join(' and ')} passenger movements. ${mode} scale.`);
      svg.append('g').attr('class','axis y-axis').attr('transform',`translate(${margin.left},0)`)
        .call(d3.axisLeft(y).ticks(4).tickSize(-(width-margin.left-margin.right)).tickFormat(app.short))
        .call(group=>group.select('.domain').remove());
      svg.append('g').attr('class','axis x-axis').attr('transform',`translate(0,${height-margin.bottom})`)
        .call(d3.axisBottom(x).ticks(4).tickSizeOuter(0).tickFormat(d3.utcFormat(view.months.length>12?'%Y':'%b')));
      svg.append('text').attr('class','axis-unit').attr('x',margin.left).attr('y',12).text('Passenger movements');
      if (!options.axesOnly) for (const type of series) {
        // [lesson:line]
        const line = d3.line()
          .defined(point => point[type].value !== null)
          .x(point => x(point.date))
          .y(point => y(point[type].value));
        svg.append('path')
          .datum(panel.values)
          .attr('d',line)
          .attr('fill','none')
          .attr('stroke',app.colors[type])
          .attr('class','data-line')
          .attr('stroke-width',2.4)
          .attr('stroke-dasharray',type === 'International' ? '5 4' : null);
        // [/lesson:line]
        svg.append('g').selectAll('circle').data(panel.values.filter(point=>point[type].value!==null)).join('circle')
          .attr('cx',point=>x(point.date)).attr('cy',point=>y(point[type].value)).attr('r',1.7).attr('fill',app.colors[type]);
      }
      if (!panel.hasData && !options.axesOnly) svg.append('text').attr('class','empty-chart').attr('x',width/2).attr('y',height/2).attr('text-anchor','middle').text('No records in selected period');
      if (options.peakMonths && !options.axesOnly && options.showPeaks !== false) {
        for (const key of series) {
          const peaks=options.peakMonths(panel.values,key);
          if (!Array.isArray(peaks) || peaks.some(point=>!panel.values.includes(point)||point[key].value===null)) throw new Error('peakMonths must return existing points with recorded values.');
          const marks=svg.append('g').attr('class','peak-markers');
          for (const point of peaks) {
            marks.append('circle').attr('cx',x(point.date)).attr('cy',y(point[key].value)).attr('r',6)
              .attr('fill','white').attr('stroke',app.colors[key]).attr('stroke-width',2.5);
            marks.append('text').attr('x',x(point.date)).attr('y',Math.max(12,y(point[key].value)-11))
              .attr('text-anchor',x(point.date)>width-margin.right-24?'end':x(point.date)<margin.left+24?'start':'middle')
              .attr('class','peak-label').text(d3.utcFormat('%b')(point.date));
          }
          if(peaks.length){const note=card.append('p').attr('class','peak-summary');app.bilingual(note.node(),`最高月份：${peaks.map(point=>app.monthLabel(point.date)).join(', ')} · ${app.cellText(peaks[0][key])} 人次`,`Peak: ${peaks.map(point=>app.monthLabel(point.date)).join(', ')} · ${app.cellText(peaks[0][key])}`);}
        }
      }
      const cursor=svg.append('line').attr('class','month-cursor').attr('y1',margin.top).attr('y2',height-margin.bottom);
      const dots=svg.append('g');
      const readout=card.append('div').attr('class','chart-readout');
      refs.push({panel,x,y,cursor,dots,readout});
      if (!options.axesOnly && options.interactive !== false) svg.append('rect').attr('x',margin.left).attr('y',margin.top).attr('width',width-margin.left-margin.right).attr('height',height-margin.top-margin.bottom).attr('fill','transparent')
        .on('pointermove click', function(event) {
          const date=x.invert(d3.pointer(event,this)[0]);
          const index=d3.bisector(date=>+date).center(view.months,+date);
          setMonth(index);
          options.onMonth?.(index);
        });
    }
    function setMonth(index) {
      index=Math.max(0,Math.min(view.months.length-1,index));
      for (const ref of refs) {
        const point=ref.panel.values[index];
        ref.cursor.attr('x1',ref.x(point.date)).attr('x2',ref.x(point.date)).attr('opacity',options.axesOnly?0:1);
        ref.dots.selectAll('circle').data(options.axesOnly?[]:series.filter(key=>point[key].value!==null)).join('circle')
          .attr('cx',ref.x(point.date)).attr('cy',key=>ref.y(point[key].value)).attr('r',4).attr('fill',key=>app.colors[key]).attr('stroke','white').attr('stroke-width',2);
        ref.readout.selectAll('*').remove();
        if(options.showMonth||options.coverage)ref.readout.append('span').attr('class','readout-month').text(app.monthLabel(point.date));
        if (options.axesOnly) ref.readout.append('span').text('Axes only at this stage');
        else for (const type of series) {
          const span=ref.readout.append('span');
          span.append('i').style('background',app.colors[type]);
          const cell=point[type],value=span.append('span');
          if (options.coverage && cell.value===null) {
            const zhLabel=({Domestic:'国内',International:'国际',Total:'合计'})[type];
            app.bilingual(value.node(),`${zhLabel}：${point.date.getUTCFullYear()} 年 ${point.date.getUTCMonth()+1} 月无记录`,`${app.trafficLabel[type]}: no record for ${app.monthLabel(point.date)}`);
          } else value.text(`${app.trafficLabel[type]}: ${app.cellText(cell)}`);
          if(cell.value!==null&&cell.count>0&&cell.count<cell.expected)span.attr('title',`${cell.count} of ${cell.expected} arrival/departure records; only reported values are added.`);
        }
      }
    }
    setMonth(options.monthIndex ?? view.months.length-1);
    return {setMonth, maxima:refs.map(ref=>ref.y.domain()[1]), refs};
  };
})();

/* English is the base language. Chinese notes are optional. */
window.LAX=window.LAX||{};
(()=>{
  const app=window.LAX;
  let shown=Boolean(window.LAX_SHOW_CHINESE);
  try { if(window.LAX_SHOW_CHINESE===undefined) shown=localStorage.getItem('lax-chinese')==='true'; } catch {}
  app.chinese=()=>shown;
  app.bilingual=(element,zh,en)=>{
    const english=document.createElement('span'),chinese=document.createElement('span');
    english.className='copy-en';english.lang='en';english.textContent=en;
    chinese.className='copy-zh';chinese.lang='zh-CN';chinese.textContent=zh;
    element.replaceChildren(english,chinese);
  };
  app.applyLanguage=(visible,persist=true)=>{
    shown=Boolean(visible);document.documentElement.classList.toggle('show-chinese',shown);
    if(persist)try{localStorage.setItem('lax-chinese',String(shown));}catch{}
    const button=document.getElementById('toggle-chinese');
    if(button){button.textContent=shown?'隐藏中文':'显示中文';button.setAttribute('aria-pressed',String(shown));}
    document.querySelectorAll('option[data-en]').forEach(option=>option.textContent=option.dataset.en+(shown&&option.dataset.zh?' · '+option.dataset.zh:''));
    document.querySelectorAll('iframe').forEach(frame=>frame.contentWindow?.postMessage({type:'lax-language',shown},'*'));
  };
  window.addEventListener('message',event=>{if(event.source===parent&&event.data?.type==='lax-language')app.applyLanguage(event.data.shown,false);});
  const setup=()=>{
    document.getElementById('toggle-chinese')?.addEventListener('click',()=>app.applyLanguage(!shown));
    document.querySelectorAll('iframe').forEach(frame=>frame.addEventListener('load',()=>frame.contentWindow?.postMessage({type:'lax-language',shown},'*')));
    app.applyLanguage(shown,false);
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup);else setup();
})();

# LAX · Peak months & panel order

## Run locally / 本地运行

1. Extract the ZIP and open its folder in VS Code. / 解压 ZIP，在 VS Code 中打开文件夹。
2. Open `learn/index.html` with Live Server. Or run `python -m http.server 8000` in the project folder and visit `http://localhost:8000/learn/index.html`. / 使用 Live Server，或按上述命令启动本地服务器。
3. Edit `learn/choices.js`, save, then refresh the browser. / 修改文件，保存后刷新。

D3 and the CSV are included. No npm installation is needed. / 包内已有 D3 和 CSV，无须安装 npm 依赖。
The top-right button shows or hides Chinese notes. / 右上角按钮可显示或隐藏中文。

## Data / 数据

The exercise uses 2022 domestic traffic at T1, T2, T6 and TBIT. A monthly value adds arrivals and departures. All four charts use the same y-axis.

练习使用 T1、T2、T6 与 TBIT 在 2022 年的国内客流。月度数值为到达与出发之和，四张图使用共享纵轴。

Source: https://data.lacity.org/Transportation/Los-Angeles-International-Airport-Passenger-Traffi/g3qu-7q2u/about_data

## Task 1 / 任务一

`peakMonths(values, key)` receives monthly points and a traffic field name. Return every point with the highest recorded value. The chart handles the ring and label.

该函数接收月度数据点与客流字段名。返回所有达到最高已记录数值的点，图表负责画圆圈与标签。

- `d3.max`: find the maximum / 找最大值。
- `Array.filter`: keep matching points / 保留符合条件的数据点。
- Return an empty array if all values are missing. Keep ties and recorded zeros. / 全部缺失时返回空数组；并列最高值与真实的零不能丢弃。

## Task 2 / 任务二

`orderPanels(panels, mode)` receives panels in terminal order. When mode is `volume`, sort a copy by `panel.reported`, descending. For `terminal`, keep the original sequence.

该函数接收按航站楼排列的小图。mode 为 volume 时，按 reported 从高到低排列数组副本；为 terminal 时保留原顺序。

The values and four-terminal total must stay the same. / 客流数值与四个航站楼的总和应保持不变。

## Check / 检查

- Peak markers appear at the highest points. / 峰值标记出现在最高点。
- Volume order is T2 → T1 → T6 → TBIT. Terminal order restores T1 → T2 → T6 → TBIT. / 两种排序可来回切换。
- The reported total stays 20,597,147. / 合计保持为 20,597,147 人次。

Reference answers are not included in the exercise starter. / 练习包不含参考答案。

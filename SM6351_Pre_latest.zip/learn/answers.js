/* Presenter reference. Not loaded by the teaching page or student starter. */
window.LAX_CHOICES = {
  peakMonths(values, key) {
    const maximum = d3.max(values, d => d[key].value);
    return values.filter(d => d[key].value === maximum);
  },
  orderPanels(panels, mode) {
    const ordered = [...panels];
    if (mode === "volume") ordered.sort((a, b) => b.reported - a.reported);
    return ordered;
  }
};

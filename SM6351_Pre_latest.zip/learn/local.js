(async()=>{
  const status=document.getElementById('local-status'),root=document.getElementById('local-charts');
  try{
    const data=await LAX.loadData('../data/lax-passengers.csv');
    const state={sort:'terminal',peaks:true};
    function render(){try{
      const result=LAX.runLesson(root,data,state,window.LAX_CHOICES);
      LAX.bilingual(status,`任务一：${result.peakCorrect?'完成':'未完成'}；任务二：${result.sortCorrect?'完成':'未完成'}。`,`Task 1: ${result.peakCorrect?'complete':'incomplete'} · Task 2: ${result.sortCorrect?'complete':'incomplete'}.`);status.className='note';
    }catch(error){status.textContent=error.message;status.className='error-panel';}}
    LAX.connectControls(document.getElementById('local-controls'),state,render);render();
  }catch(error){status.textContent='Exercise could not load: '+error.message;status.className='error-panel';}
})();
/* Edit the two TODOs, save, then refresh learn/index.html.
   The webpage shows only the editable function bodies. */
window.LAX_CHOICES = {
  peakMonths(values, key) {
    // [edit:peak]
    const maximum = d3.max(values, d => d[key].value);
    // TODO 1: return every recorded point equal to maximum.
    return [];
    // [/edit:peak]
  },
  orderPanels(panels, mode) {
    // [edit:sort]
    const ordered = [...panels];
    // TODO 2: sort by reported total when mode is "volume".
    return ordered;
    // [/edit:sort]
  }
};
